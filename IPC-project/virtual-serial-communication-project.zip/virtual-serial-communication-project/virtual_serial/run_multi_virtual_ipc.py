from hihi import main
from hihi2 import main2

main()
main2()
